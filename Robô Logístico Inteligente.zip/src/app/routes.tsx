import { createBrowserRouter } from "react-router";
import { Home } from "./pages/Home";
import { DataEntry } from "./pages/DataEntry";
import { Results } from "./pages/Results";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Home,
  },
  {
    path: "/entrada-dados",
    Component: DataEntry,
  },
  {
    path: "/resultados",
    Component: Results,
  },
]);
