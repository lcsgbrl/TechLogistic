import { useNavigate } from 'react-router';
import { Package, TruckIcon, MapPin } from 'lucide-react';

export function Home() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="container mx-auto px-4 py-12">
        {/* Header */}
        <header className="text-center mb-16">
          <div className="flex items-center justify-center gap-3 mb-4">
            <TruckIcon className="w-12 h-12 text-blue-600" />
            <h1 className="text-slate-800">Robô Logístico Inteligente</h1>
          </div>
          <p className="text-slate-600 max-w-2xl mx-auto">
            Sistema acadêmico para gerenciamento e otimização de rotas logísticas.
          </p>
          <div className="mt-2 text-sm text-slate-500">
            Desenvolvido por: Equipe de Sistemas de Informação - TSP
          </div>
        </header>

        {/* Main Content */}
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-lg shadow-md p-12 text-center">
            <div className="flex justify-center gap-12 mb-12">
              <div className="flex flex-col items-center">
                <div className="w-16 h-16 bg-blue-100 rounded-lg flex items-center justify-center mb-3">
                  <Package className="w-8 h-8 text-blue-600" />
                </div>
                <span className="text-sm text-slate-600">Gestão de Produtos</span>
              </div>
              <div className="flex flex-col items-center">
                <div className="w-16 h-16 bg-blue-100 rounded-lg flex items-center justify-center mb-3">
                  <MapPin className="w-8 h-8 text-blue-600" />
                </div>
                <span className="text-sm text-slate-600">Otimização de Rotas</span>
              </div>
              <div className="flex flex-col items-center">
                <div className="w-16 h-16 bg-blue-100 rounded-lg flex items-center justify-center mb-3">
                  <TruckIcon className="w-8 h-8 text-blue-600" />
                </div>
                <span className="text-sm text-slate-600">Coleta Eficiente</span>
              </div>
            </div>

            <button
              onClick={() => navigate('/entrada-dados')}
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg transition-colors"
            >
              Iniciar Sistema
            </button>
          </div>

          {/* Info Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-slate-800 mb-2">Cadastro Simples</h3>
              <p className="text-sm text-slate-600">
                Interface intuitiva para cadastro de produtos e setores do armazém.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-slate-800 mb-2">Algoritmo Otimizado</h3>
              <p className="text-sm text-slate-600">
                Cálculo automático da melhor rota para coleta de produtos.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-slate-800 mb-2">Resultados Claros</h3>
              <p className="text-sm text-slate-600">
                Visualização gráfica da rota com métricas de desempenho.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
