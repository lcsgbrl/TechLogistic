
  # Robô Logístico Inteligente

  This is a code bundle for Robô Logístico Inteligente. The original project is available at https://www.figma.com/design/zXlqEdRs52JulEZW4odzxQ/Rob%C3%B4-Log%C3%ADstico-Inteligente.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  